@echo off
title Desinstalar DC-Tuner Studio
setlocal
set "TARGET=%LOCALAPPDATA%\DC-Tuner Studio"
del "%USERPROFILE%\Desktop\DC-Tuner Studio.lnk" >nul 2>&1
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\DC-Tuner Studio.lnk" >nul 2>&1
if exist "%TARGET%" rmdir /s /q "%TARGET%"
echo DC-Tuner Studio desinstalado.
pause
exit /b
