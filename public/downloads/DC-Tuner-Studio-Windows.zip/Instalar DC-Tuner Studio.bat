@echo off
title Instalador de DC-Tuner Studio
setlocal
set "TARGET=%LOCALAPPDATA%\DC-Tuner Studio"
echo Instalando DC-Tuner Studio en:
echo   %TARGET%
echo.
if not exist "%TARGET%" mkdir "%TARGET%"
copy /y "%~dp0DC-Tuner Studio.bat" "%TARGET%\" >nul
if exist "%~dp0app-icon.ico" copy /y "%~dp0app-icon.ico" "%TARGET%\" >nul
if exist "%~dp0LEEME.txt" copy /y "%~dp0LEEME.txt" "%TARGET%\" >nul

set "DESKTOP=%USERPROFILE%\Desktop"
powershell -NoProfile -Command ^
  "$s=(New-Object -ComObject WScript.Shell);" ^
  "$l=$s.CreateShortcut('%DESKTOP%\DC-Tuner Studio.lnk');" ^
  "$l.TargetPath='%TARGET%\DC-Tuner Studio.bat';" ^
  "$l.WorkingDirectory='%TARGET%';" ^
  "$l.IconLocation='%TARGET%\app-icon.ico';" ^
  "$l.Description='DC-Tuner Studio';" ^
  "$l.Save();" ^
  "$m=$s.CreateShortcut('%APPDATA%\Microsoft\Windows\Start Menu\Programs\DC-Tuner Studio.lnk');" ^
  "$m.TargetPath='%TARGET%\DC-Tuner Studio.bat';" ^
  "$m.WorkingDirectory='%TARGET%';" ^
  "$m.IconLocation='%TARGET%\app-icon.ico';" ^
  "$m.Save()"

echo.
echo Listo. Se han creado accesos directos en el escritorio y en el menu Inicio.
echo Abriendo DC-Tuner Studio...
start "" "%TARGET%\DC-Tuner Studio.bat"
exit /b
